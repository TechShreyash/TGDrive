Movi Player 0.4.1 source and relinking materials
================================================

This archive accompanies the unmodified decoder WASM in TGDrive's enhanced
browser viewer. It does not contain private configuration or runtime state.

Contents
--------
sources/ffmpeg-n9.0.2.tar.gz: complete upstream FFmpeg source archive
sources/dav1d-1.5.3.tar.gz: complete upstream VideoLAN dav1d source archive
movi-source/: all src, wasm, docker, scripts, framework-wrapper code and package
  build configuration at published npm gitHead
  eaaa3088aba65454176a180ece2a2ef2af513fa3 (screenshots/demo media/docs omitted).
  wasm/signalsmith includes the complete linked Stretch/Linear source+licenses.
published-libraries/: exact installed npm WASM-target FFmpeg/dav1d static
  archives, installed headers and pkg-config files, usable as relink inputs.
licenses/: unchanged npm license with component notices and full LGPL-2.1.
source-manifest.json: SHA-256 of each payload, plus delivered WASM identity.

Provenance and limits
---------------------
Package source:
https://github.com/MrUjjwalG/movi-player/tree/eaaa3088aba65454176a180ece2a2ef2af513fa3
FFmpeg source:
https://github.com/FFmpeg/FFmpeg/tree/n9.0.2
dav1d source:
https://code.videolan.org/videolan/dav1d/-/tree/1.5.3

The unchanged npm license labels FFmpeg n8.1.2. The same published source's
Dockerfile explicitly selects n9.0.2. Its installed static-library headers and
pkg-config files identify libavcodec/libavformat 63.1.102, and the delivered
WASM contains the same NUL-delimited libavcodec version plus
dav1d 1.5.3-0-gb546257. These agree with the n9.0.2/1.5.3 source build inputs;
n8.1.2's libavcodec is 62.28.102. The evidence and original notice are both
preserved. The exact patch provenance is inferred from the published recipe,
not recovered independently from a reproducible build. No byte-identical
rebuild, toolchain provenance attestation or legal conclusion is claimed.

The upstream build recipe enables neither --enable-gpl nor --enable-nonfree.
The FFmpeg libraries are linked statically into the WASM module. Application
C/C++ sources and relink inputs are supplied here so the recipient can replace
or modify the LGPL component and relink. Read licenses/FFmpeg-LGPL-2.1.txt.

Rebuild from complete sources (Linux or WSL Ubuntu)
--------------------------------------------------
Install Docker Engine/Compose for Linux and use a Linux shell. Review the
included Dockerfile/build script before executing it. Emscripten instructions:
https://emscripten.org/docs/getting_started/downloads.html

Upstream does not pin its emscripten/emsdk:latest base. Select and record an
available Emscripten image version/digest before a reproducible release build.
The published archives record LLVM 24.0.0git; compatible LTO input support is
required to reuse them. Rebuilding both libraries avoids relying on that LTO
compatibility. This source package does not assert a tested SDK version.

For the upstream online build, from movi-source/:
  docker build --build-arg FFMPEG_VERSION=n9.0.2     --build-arg DAV1D_VERSION=1.5.3 -t tgdrive-movi-builder docker
  docker run --rm -v "$(pwd):/src" tgdrive-movi-builder

This downloads the upstream sources at the same selected tags. To use the
included complete archives instead, extract them into a separate work
directory and mount those source roots over /opt/FFmpeg and /opt/dav1d in the
builder container. FFMPEG_SRC is /opt/FFmpeg. The script's DAV1D_SRC points to
/opt/dav1d. The build environment also needs meson, ninja, pkg-config and make,
as declared by docker/Dockerfile. No FFmpeg patches are applied by TGDrive.

The unmodified recipe has the configure options and application/link flags.
It compiles wasm/*.c, wasm/*.cpp and the included Signalsmith headers, then
links with libavformat, libavcodec, libdav1d, libavutil, libswresample and
libswscale. It emits:
  dist/wasm/movi.js                 embedded-WASM build
  dist/wasm/external/movi.js         external-WASM glue
  dist/wasm/external/movi.wasm       replaceable external module

Relink against the published static libraries
--------------------------------------------
Copy published-libraries/ffmpeg and published-libraries/dav1d into
movi-source/dist/ffmpeg and movi-source/dist/dav1d. With an Emscripten compiler
compatible with their LLVM bitcode, run the same included build script in
/src. It detects the existing archives and skips their source build, then
recompiles the supplied application C/C++ and relinks. To use modified FFmpeg,
rebuild/replace dist/ffmpeg first or set FORCE_FFMPEG=true. The recipe documents
the interface exports and link flags; it does not conceal the LGPL boundary.

Using a rebuilt module
----------------------
The TGDrive React source imports the external WASM as a local Vite asset.
Replace that source asset/import with the rebuilt external module, rebuild the
frontend, and deploy the resulting matching JS/WASM. A newly hashed asset URL
avoids stale caches. If compiler ABI/glue changes, rebuild Movi's standalone
slim JS with its included scripts and package build configuration too; do not
assume arbitrary incompatible WASM modules work with the published glue.

Inspect browser console/network errors and verify actual video, EAC3 audio,
track changes, subtitles, ranges/seeking and close/cancellation. A source
rebuild has not been executed as part of TGDrive's current candidate checks.
